##servlet3-maven-archetype

Project provides Maven archetype for creating plain simple Servlet 3 based webapplication

Read more on github.io page:
<http://maciejwalkowiak.github.io/servlet3-maven-archetype/>

========================
Check out also my development blog: <http://maciejwalkowiak.pl/blog>

[![Bitdeli Badge](https://d2weczhvl823v0.cloudfront.net/maciejwalkowiak/servlet3-maven-archetype/trend.png)](https://bitdeli.com/free "Bitdeli Badge")

