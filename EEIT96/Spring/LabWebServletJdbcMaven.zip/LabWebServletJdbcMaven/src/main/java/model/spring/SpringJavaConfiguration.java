package model.spring;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import model.CustomerDAO;
import model.CustomerService;
import model.ProductService;
import model.dao.CustomerDAOJdbc;
import model.dao.ProductDAOJdbc;

@Configuration
public class SpringJavaConfiguration {

	@Bean
	public DataSource dataSource() {
		try {
			Context ctx = new InitialContext();
			return (DataSource) ctx.lookup("java:comp/env/jdbc/xxx");
		} catch (NamingException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@Bean
	public ProductService productService() {
		return new ProductService(new ProductDAOJdbc(dataSource()));
	}

	@Bean
	public CustomerDAO customerDao() {
		return new CustomerDAOJdbc(dataSource());
	}
	
	@Bean
	public CustomerService customerService() {
		return new CustomerService(customerDao());
	}
}
