create table customer(
custID bigint,
name varchar(30),
age bigint
)

select * from customer